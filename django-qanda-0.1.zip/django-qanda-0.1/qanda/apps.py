from django.apps import AppConfig


class QandaConfig(AppConfig):
    name = 'qanda'
